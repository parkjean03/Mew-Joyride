Description:
The name of this project is called “Mew Joyride”. 
This project will focus mainly on replicating the gameplay of "Jetpack Joyride", 
a side scroller game, while also maintaining the galactic design and feel to the game.

How to run:
In order to run this game, you must open the file "jetpack.py" and run the file through python. 
You must run this file within the folder. The images must remain inside the folder for the game to run properly. 

Controls: 
(UP, DOWN, LEFT, RIGHT) = These keys are used to move the character in the direction directed by the player. 
(SPACE) = This key is used for the player to shoot the falling planets to gain points and eliminate the obstacle. 
(R) = This keyboard command is used for the player if they want to restart the current game 
(P) = This keyboard command is used for the player to pause the game. 

How to play the game:
1) Select one of the levels after the start up screen to play in the desired difficulty. 
2) Dodge over the randomly generated walls and planets to gain score and to not die. 
3) Use the space bar to shoot beams to eliminate planets to get points. 
4) Collect diamonds on the way to increase points on the way.
5) Once the player gains 30 points, the game will now transition over to a boss mode. 
6) In the boss mode, the player must fire the beams to eliminate the planets from the boss. 
7) If the planet is eliminated, the boss loses 100 health. 
8) If the planet hits the player, the game is immediately lost. 
9) Once the player manages to take down all of the boss's health, the player wins. 
