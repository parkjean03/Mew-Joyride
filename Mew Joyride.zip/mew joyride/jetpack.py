#Name: Jean Park
#Andrew ID: jeanp 

import math, copy, random
from cmu_112_graphics import *
import os 
import time

class SplashScreenMode(Mode):
    def appStarted(mode):
        mode.mewLogo0 = mode.loadImage('mewlogo.png')
        #image from https://www.pngaaa.com/detail/2542660 
        mode.mewLogo = mode.scaleImage(mode.mewLogo0, 0.6)
        mode.galaxy0 = mode.loadImage('galaxy.png')
        #image from https://galactic-castle.tumblr.com/post/175694746684
        mode.galaxy = mode.scaleImage(mode.galaxy0, 1.2)
        mode.joy = mode.loadImage('joy.png')
        #image from https://www.steamgriddb.com/logo/26876
        mode.letterX0 = mode.loadImage('x.png')
        #image from https://www.nicepng.com/ourpic/u2q8r5o0u2i1q8r5_small-silver-letter-x/
        mode.letterX = mode.scaleImage(mode.letterX0, 1/8)
        mode.startButton0 = mode.loadImage('start.png')
        #image from http://pixelartmaker.com/art/d7d0cc479df875d
        mode.startButton = mode.scaleImage(mode.startButton0, 0.8)

    def redrawAll(mode, canvas):
        canvas.create_image(500, -100, image=ImageTk.PhotoImage(mode.galaxy))
        canvas.create_image(300, 180, image=ImageTk.PhotoImage(mode.mewLogo))
        canvas.create_image(700, 180, image=ImageTk.PhotoImage(mode.joy))
        canvas.create_image(500, 190, image=ImageTk.PhotoImage(mode.letterX))
        canvas.create_image(500, 350, image=ImageTk.PhotoImage(mode.startButton))

    def mousePressed(mode, event):
        if 386 < event.x < 624 and 316 < event.y < 394:
            mode.app.setActiveMode(mode.app.splashScreenModeTwo)

class SplashScreenModeTwo(Mode):
    def appStarted(mode):
        mode.levelScreen0 = mode.loadImage('loadingScreen.png')
        #image from https://twitter.com/norma_2d/status/1031998350390902790
        mode.levelScreen = mode.scaleImage(mode.levelScreen0, 1.4)
        mode.levelLetters0 = mode.loadImage('level.png')
        mode.levelLetters = mode.scaleImage(mode.levelLetters0, 3)
        mode.easyButton0 = mode.loadImage('easy.png')
        #image from http://pixelartmaker.com/art/0c15f08c1974160
        mode.easyButton = mode.scaleImage(mode.easyButton0, 0.7)
        mode.okayButton0 = mode.loadImage('medium.png')
        #image from http://pixelartmaker.com/art/315554f5bdf2f6d
        mode.okayButton = mode.scaleImage(mode.okayButton0, 0.7)
        mode.hardButton0 = mode.loadImage('hard.png')
        #image from http://pixelartmaker.com/art/e6bd5e70900bb22
        mode.hardButton = mode.scaleImage(mode.hardButton0, 0.7)
    
    def redrawAll(mode, canvas):
        canvas.create_image(500, 200, image=ImageTk.PhotoImage(mode.levelScreen))
        canvas.create_image(520, 50, image=ImageTk.PhotoImage(mode.levelLetters))
        canvas.create_image(495, 200, image=ImageTk.PhotoImage(mode.easyButton))
        canvas.create_image(495, 300, image=ImageTk.PhotoImage(mode.okayButton))
        canvas.create_image(495, 400, image=ImageTk.PhotoImage(mode.hardButton))
    
    def mousePressed(mode, event):
        if 407 < event.x < 581 and 166 < event.y < 233:
            mode.app.setActiveMode(mode.app.gameMode)
        if 407 < event.x < 581 and 266 < event.y < 332:
            mode.app.setActiveMode(mode.app.gameModeMedium)
        if 407 < event.x < 581 and 368 < event.y < 431:
            mode.app.setActiveMode(mode.app.gameModeHard)

class GameMode(Mode):
    def appStarted(mode):
        mode.timerDelay = 50
        mode.obstacleOn = False
        mode.characterX = 50
        mode.characterY = mode.height - 50
        mode.alive = True
        mode.falling = False 
        mode.score = 0 
        mode.gameOver = False 
        mode.margin = 5 
        mode.paused = False 
        mode.mew = mode.loadImage('mew.png')
        #image from https://www.pngitem.com/middle/ihmxRTw_hat-png-images-transparent-pixel-art-pokemon-mew/
        mode.mewScaled = mode.scaleImage(mode.mew, 1/10)
        mode.background0 = mode.loadImage('background.jpg')
        #image from https://wallpapersden.com/cyrodiil-pixel-art-wallpaper/800x1280/
        mode.background = mode.scaleImage(mode.background0, 1.6)
        mode.hearts0 = mode.loadImage('hearts.png')
        #image from https://www.pngkit.com/bigpic/u2q8a9t4i1q8y3r5/
        mode.hearts = mode.scaleImage(mode.hearts0, 1/25)
        mode.heartsX = 30 
        mode.heartsY = 30 
        mode.diamond0 = mode.loadImage('diamond.png')
        #https://toppng.com/minecraft-diamond-wallpaper-pin-pin-diamond-minecraft-pixel-art-minecraft-diamant-PNG-free-PNG-Images_251843?search-result=minecraft-number-8
        mode.diamond = mode.scaleImage(mode.diamond0, 1/8)
        mode.diamondX = mode.width
        mode.diamondY = random.randint(0, 300) 
        #mode.diamonds = [] pop the diamond (x,y)
        powerUps = [mode.diamond]
        mode.earth0 = mode.loadImage('earth.png')
        #image from http://pixelartmaker.com/art/4a656cb5e171a69
        mode.earth = mode.scaleImage(mode.earth0, 0.3)
        mode.mars0 = mode.loadImage('mars.png')
        #image from http://pixelartmaker.com/art/ede5adce918dcf4
        mode.mars = mode.scaleImage(mode.mars0, 0.3)
        mode.moon0 = mode.loadImage('moon.png')
        #image from https://www.reddit.com/r/PixelArt/comments/99ipqb/cc_moon_pixel_art_i_would_like_some_feed_back/
        mode.moon = mode.scaleImage(mode.moon0, 0.1)
        mode.planets = ["earth", "mars", "moon"]
        mode.heartCount = 3
        mode.bullet0 = mode.loadImage('bullet.png')
        #image from http://pixelartmaker.com/gallery?after=638985
        mode.bullet = mode.scaleImage(mode.bullet0, 0.1)
        mode.bullets = [] 
        mode.wallList = [] 
        mode.heartList = [mode.heartsX, mode.heartsX+45, mode.heartsX+90] 
        mode.collision = False
        mode.diamondCount = 0 
        mode.planetX = random.randint(500, 1000)
        mode.planetY = -100
        mode.planetList = []
        mode.fallingPlanet = "planet" 
        mode.randomPlanetNumber = 0
        mode.allowEarth = False
        mode.allowMars = False 
        mode.allowMoon = False
        mode.wallList2 = []

    def keyPressed(mode, event): 
        if (event.key == 'Up'):      
            if mode.score < 10:
                mode.moveCharacter(0, -40)
            else: 
                mode.moveCharacter(0, -50)
        elif (event.key == 'Down'):  
            if mode.score < 10: 
                mode.moveCharacter(0, 30) 
            else: 
                mode.moveCharacter(0, 50)
        elif (event.key == 'Left'):  
            mode.moveCharacter(-20, 0) 
        elif (event.key == 'Right'): 
            mode.moveCharacter(20, 0)
        elif (event.key == 'r'):
            mode.appStarted()
        elif (event.key == 'Space'):
            mode.fireBullet() 
        elif (event.key == 'p'):
            mode.paused = not mode.paused
        else:
            mode.Falling = True 
            move.fallingCharacter()

    def fireBullet(mode):
        originBulletX = mode.characterX + 20 
        startBulletX = mode.characterX + 20 
        startBulletY = mode.characterY    
        mode.bullets.append([startBulletX, startBulletY, originBulletX])

    def drawBullet(mode, canvas):
        for bullet in mode.bullets:
            canvas.create_image(bullet[0], bullet[1], image=ImageTk.PhotoImage(mode.bullet))

    def moveBullet(mode):
        for i in range(len(mode.bullets)):
            bulletTrajX = mode.bullets[i][0] + 50
            bulletTrajY = mode.bullets[i][1] 
            mode.bullets[i] = [bulletTrajX, bulletTrajY, mode.bullets[i][2]]

    def removeBullet(mode):
        i = 0 
        while i < len(mode.bullets):
            if mode.bullets[i][0] - mode.bullets[i][2] > 500:
                mode.bullets.pop(i)
            else: 
                i += 1 

    def randomPlanets(mode):
        randomNumber = random.choice([0, 1, 2])
        mode.randomPlanetNumber = randomNumber

    def fallingPlanets(mode):
        if mode.planetX > 0: 
            mode.planetX -= 20 
            mode.planetY += 20

    def generatePlanets(mode):
        if (len(mode.planetList) == 1 and mode.planetX < 300) or (len(mode.planetList) == 0):
            if mode.randomPlanetNumber == 0:
                mode.fallingPlanet = mode.planets[0]
            elif mode.randomPlanetNumber == 1:
                mode.fallingPlanet = mode.planets[1]
            elif mode.randomPlanetNumber == 2: 
                mode.fallingPlanet = mode.planets[2]
            mode.planetList.append(mode.fallingPlanet)
        if mode.planetX == 0: 
            mode.planetX = random.randint(500, 1000)
            mode.planetY = 0

    def createPlanets(mode):
        for planet in mode.planetList:
            if planet == "earth":
                mode.allowEarth = True
            if planet == "mars":
                mode.allowMars = True 
            if planet == "moon":
                mode.allowMoon = True

    def drawEarth(mode, canvas):
        if mode.allowEarth == True:
            canvas.create_image(mode.planetX, mode.planetY, image=ImageTk.PhotoImage(mode.earth))
  
    def drawMars(mode, canvas):
        if mode.allowMars == True: 
            canvas.create_image(mode.planetX, mode.planetY, image=ImageTk.PhotoImage(mode.mars))
    
    def drawMoon(mode, canvas):
        if mode.allowMoon == True:
            canvas.create_image(mode.planetX, mode.planetY, image=ImageTk.PhotoImage(mode.moon))
    
    def bulletHitsPlanet(mode):
        for i in range(len(mode.bullets)):
            if (mode.bullets[i][0]- 50 < mode.planetX < mode.bullets[i][0] + 50 
            and mode.bullets[i][1]- 50  <mode.planetY < mode.bullets[i][1] + 50):
                mode.score += 1 
                mode.planetX = random.randint(500, 1000)
                mode.planetY = 0 

    def createDiamond(mode, canvas):
        canvas.create_image(mode.diamondX, mode.diamondY, 
                            image=ImageTk.PhotoImage(mode.diamond))

    def moveDiamond(mode):
        if mode.diamondX >= 0:
            mode.diamondX -= 40 
        else: 
            mode.diamondX = 1000
            mode.diamondY = random.randint(0, 500) 
    
    def checkDiamond(mode):
        if (mode.characterX - 30 <= mode.diamondX < mode.characterX + 30 and
            mode.characterY - 30 <= mode.diamondY <= mode.characterY + 30):
            mode.score += 1 
            mode.diamondCount += 1
            mode.diamondX = 1000
            mode.diamondY = random.randint(0, 500) 

    def createHearts(mode, canvas):
        for i in range(mode.heartCount):
            canvas.create_image(mode.heartList[i], mode.heartsY, 
                                image=ImageTk.PhotoImage(mode.hearts))

    def calculateHearts(mode):
        if mode.heartCount > 0:  
            if mode.collision == True:
                mode.characterX = 50
                mode.characterY = mode.height/2   
                mode.heartList.pop()
                mode.heartCount -= 1
                mode.collision = False 
            for wall in mode.wallList:
                if ((wall[0] < mode.characterX <= wall[2] 
                        and wall[1] < mode.characterY < wall[3])
                    or
                    (mode.planetX - 40 < mode.characterX < mode.planetX + 40
                        and mode.planetY - 40 < mode.characterY < mode.planetY + 40)):
                    #it reads it but does not work..? 
                    mode.collision = True 

            if mode.wallList2 != []:
                for wall in mode.wallList2: 
                    if (wall[0] < mode.characterX < wall[2] 
                            and wall[1] < mode.characterY < wall[3]):
                        mode.collision = True

        elif mode.heartCount == 0:
            mode.gameOver = True  
        #check the lowerbound with Y2
        #check the upperbound with Y1     

    def createBackground(mode, canvas):
        canvas.create_image(500, 260, 
                            image=ImageTk.PhotoImage(mode.background))

    def createCharacter(mode, canvas):
        if mode.alive:
            canvas.create_image(mode.characterX-10,mode.characterY-10,
                            image=ImageTk.PhotoImage(mode.mewScaled))

    def moveCharacter(mode, dx, dy):
        if 0 <= mode.characterX <= 1000 and 0 <= mode.characterY <= 500:
            mode.characterX += dx 
            mode.characterY += dy 

    def fallingCharacter(mode):
        if mode.characterY <= 485:
            mode.characterY += 8

    def randomWall(mode):
        randomNumber = random.choice([0, 1, 2, 3, 4, 4, 4, 5])
        if randomNumber == 0:
            return "0"
        if randomNumber == 1:
            return "1"
        if randomNumber == 2:
            return "2"
        if randomNumber == 3:
            return "3"
        if randomNumber == 4:
            return "4"
        if randomNumber == 5:
            return "5"

    def drawWall(mode, canvas):
        for wall in mode.wallList:
            canvas.create_rectangle(
                wall[0], wall[1], wall[2], wall[3], fill = "black")
        for wall in mode.wallList2:
            canvas.create_rectangle(
                wall[0], wall[1], wall[2], wall[3], fill = "black")
        
    def createWall(mode):
        if (len(mode.wallList) == 1 and mode.wallList[0][2] < 500) or (len(mode.wallList) == 0):
            obsX0 = mode.width 
            obsX1 = 1100
            if mode.randomWall() == "0":
                obsY0 = mode.height - random.randint(100, 400)
                obsY1 = mode.height
            elif mode.randomWall() == "1":
                obsY0 = random.randint(200, 400)
                obsY1 = random.randint(300, 400)
            elif mode.randomWall() == "2":
                obsY0 = mode.height - random.randint(100, 400)
                obsY1 = mode.height
                obsX1 = random.randint(1200,1400)
            elif mode.randomWall() == "3":
                obsY0 = 0
                obsY1 = random.randint(100, 400)
                obsX1 = random.randint(1200,1400)
            elif mode.randomWall() == "4":
                obsY0 = 0 
                obsY1 = random.randint(100, 200)
                obsY2 = mode.height - random.randint(100, 300)
                obsY3 = mode.height 
                while obsY2 - obsY1 < mode.mewScaled.size[1]: 
                    obsY1 = random.randint(100, 200)
                    obsY2 = mode.height - random.randint(100, 300)
                mode.wallList2.append([obsX0, obsY2, obsX1, obsY3, False])
            else:
                obsY0 = 0
                obsY1 = random.randint(100, 400)
            mode.wallList.append([obsX0, obsY0, obsX1, obsY1, False])
            
        
    def moveWall(mode):
        for wall in mode.wallList:
            if wall[2] >= 0:
                wall[0] -= 25 
                wall[2] -= 25 
                if mode.score >= 10:
                    wall[0] -= 35 
                    wall[2] -= 35 
                    if mode.score >= 20:
                        wall[0] -= 45
                        wall[2] -= 45 
        for wall in mode.wallList2:
            if wall[2] > 0:
                wall[0] -= 25
                wall[2] -= 25 
                if mode.score > 10:
                    wall[0] -= 35 
                    wall[2] -= 35
                    if mode.score >= 20:
                        wall[0] -= 45
                        wall[2] -= 45 

    def removeWall(mode):
        i = 0
        while i < len(mode.wallList):
            if mode.wallList[i][2] <= 0:
                mode.wallList.pop(i)
                if mode.wallList2 != []:
                    if mode.wallList2[i][2] <= 0:
                        mode.wallList2.pop(i)
            else: 
                i += 1 

    def movedPastObstacle(mode):
        for wall in mode.wallList:
            if mode.characterX > wall[2] and wall[4] == False:
                mode.score += 1
                wall[4] = True

    def collisionWall(mode):
        for wall in mode.wallList:
            if wall[0] < mode.characterX < wall[2] and wall[0] < mode.characterY < wall[3]:
                mode.collision = True 

    def goGameOver(mode):
        if mode.gameOver == True:
            mode.appStarted()
            mode.app.setActiveMode(mode.app.gameOverScreen)   

    def drawScore(mode, canvas):
        canvas.create_text(930, 18, text = f'Score: {mode.score}/30', 
        fill = 'white', font = f'arial 20 roman bold')
        canvas.create_text(750, 18, text = f'Diamond Collected: {mode.diamondCount}', 
        fill = 'white', font = f'arial 20 roman bold')
    
    def bossEntrance(mode):
        if mode.score == 30: 
            mode.app.setActiveMode(mode.app.easyBossTransition)

    def timerFired(mode):
        if (not mode.paused):
            mode.fallingPlanets()
            mode.calculateHearts()
            #mode.collisionWall()
            mode.movedPastObstacle()
            mode.checkDiamond()
            mode.createWall()
            mode.moveWall() 
            mode.removeWall()
            mode.fallingCharacter()
            mode.moveDiamond() 
            mode.randomPlanets()
            mode.moveBullet() 
            mode.removeBullet()
            mode.bossEntrance()
            mode.goGameOver()
            mode.generatePlanets()
            mode.createPlanets()
            mode.bulletHitsPlanet()
        if mode.gameOver == False:
            mode.movedPastObstacle()

    def redrawAll(mode, canvas): 
        mode.createBackground(canvas)
        mode.createHearts(canvas)
        mode.createDiamond(canvas)
        mode.drawWall(canvas)
        mode.createCharacter(canvas)
        mode.drawScore(canvas)
        mode.drawBullet(canvas)
        mode.drawEarth(canvas)
        mode.drawMoon(canvas)
        mode.drawMars(canvas)

class GameModeMedium(Mode):
    def appStarted(mode):
        mode.timerDelay = 50
        mode.obstacleOn = False
        mode.characterX = 50
        mode.characterY = mode.height - 50
        mode.alive = True
        mode.falling = False 
        mode.score = 0 
        mode.gameOver = False 
        mode.margin = 5 
        mode.paused = False 
        mode.mew = mode.loadImage('mew.png')
        #image from https://www.pngitem.com/middle/ihmxRTw_hat-png-images-transparent-pixel-art-pokemon-mew/
        mode.mewScaled = mode.scaleImage(mode.mew, 1/10)
        mode.background0 = mode.loadImage('background.jpg')
        #image from https://wallpapersden.com/cyrodiil-pixel-art-wallpaper/800x1280/
        mode.background = mode.scaleImage(mode.background0, 1.6)
        mode.hearts0 = mode.loadImage('hearts.png')
        #image from https://www.pngkit.com/bigpic/u2q8a9t4i1q8y3r5/
        mode.hearts = mode.scaleImage(mode.hearts0, 1/25)
        mode.heartsX = 30 
        mode.heartsY = 30 
        mode.diamond0 = mode.loadImage('diamond.png')
        #https://toppng.com/minecraft-diamond-wallpaper-pin-pin-diamond-minecraft-pixel-art-minecraft-diamant-PNG-free-PNG-Images_251843?search-result=minecraft-number-8
        mode.diamond = mode.scaleImage(mode.diamond0, 1/8)
        mode.diamondX = mode.width
        mode.diamondY = random.randint(0, 300) 
        #mode.diamonds = [] pop the diamond (x,y)
        powerUps = [mode.diamond]
        mode.earth0 = mode.loadImage('earth.png')
        #image from http://pixelartmaker.com/art/4a656cb5e171a69
        mode.earth = mode.scaleImage(mode.earth0, 0.3)
        mode.mars0 = mode.loadImage('mars.png')
        #image from http://pixelartmaker.com/art/ede5adce918dcf4
        mode.mars = mode.scaleImage(mode.mars0, 0.3)
        mode.moon0 = mode.loadImage('moon.png')
        #image from https://www.reddit.com/r/PixelArt/comments/99ipqb/cc_moon_pixel_art_i_would_like_some_feed_back/
        mode.moon = mode.scaleImage(mode.moon0, 0.1)
        mode.planets = ["earth", "mars", "moon"]
        mode.heartCount = 3
        mode.bullet0 = mode.loadImage('bullet.png')
        #image from http://pixelartmaker.com/gallery?after=638985
        mode.bullet = mode.scaleImage(mode.bullet0, 0.1)
        mode.bullets = [] 
        mode.wallList = [] 
        mode.heartList = [mode.heartsX, mode.heartsX+45, mode.heartsX+90] 
        mode.collision = False
        mode.diamondCount = 0 
        mode.planetX = random.randint(500, 1000)
        mode.planetY = -100
        mode.planetList = []
        mode.fallingPlanet = "planet" 
        mode.randomPlanetNumber = 0
        mode.allowEarth = False
        mode.allowMars = False 
        mode.allowMoon = False
        mode.wallList2 = []
        mode.okayScreen0 = mode.loadImage('mediumscreen.png')
        #image from https://weheartit.com/entry/335148442
        mode.okayScreen = mode.scaleImage(mode.okayScreen0, 1.3)

    def keyPressed(mode, event): 
        if (event.key == 'Up'):      
            if mode.score < 10:
                mode.moveCharacter(0, -40)
            else: 
                mode.moveCharacter(0, -50)
        elif (event.key == 'Down'):  
            if mode.score < 10: 
                mode.moveCharacter(0, 30) 
            else: 
                mode.moveCharacter(0, 50) 
        elif (event.key == 'Left'):  
            mode.moveCharacter(-20, 0) 
        elif (event.key == 'Right'): 
            mode.moveCharacter(20, 0)
        elif (event.key == 'r'):
            mode.appStarted()
        elif (event.key == 'Space'):
            mode.fireBullet() 
        elif (event.key == 'p'):
            mode.paused = not mode.paused
        else:
            mode.Falling = True 
            move.fallingCharacter()

    def fireBullet(mode):
        originBulletX = mode.characterX + 20 
        startBulletX = mode.characterX + 20 
        startBulletY = mode.characterY    
        mode.bullets.append([startBulletX, startBulletY, originBulletX])

    def drawBullet(mode, canvas):
        for bullet in mode.bullets:
            canvas.create_image(bullet[0], bullet[1], image=ImageTk.PhotoImage(mode.bullet))

    def moveBullet(mode):
        for i in range(len(mode.bullets)):
            bulletTrajX = mode.bullets[i][0] + 50
            bulletTrajY = mode.bullets[i][1] 
            mode.bullets[i] = [bulletTrajX, bulletTrajY, mode.bullets[i][2]]

    def removeBullet(mode):
        i = 0 
        while i < len(mode.bullets):
            if mode.bullets[i][0] - mode.bullets[i][2] > 500:
                mode.bullets.pop(i)
            else: 
                i += 1 

    def randomPlanets(mode):
        randomNumber = random.choice([0, 1, 2])
        mode.randomPlanetNumber = randomNumber

    def fallingPlanets(mode):
        if mode.planetX > 0: 
            mode.planetX -= 20 
            mode.planetY += 20

    def generatePlanets(mode):
        if (len(mode.planetList) == 1 and mode.planetX < 300) or (len(mode.planetList) == 0):
            if mode.randomPlanetNumber == 0:
                mode.fallingPlanet = mode.planets[0]
            elif mode.randomPlanetNumber == 1:
                mode.fallingPlanet = mode.planets[1]
            elif mode.randomPlanetNumber == 2: 
                mode.fallingPlanet = mode.planets[2]
            mode.planetList.append(mode.fallingPlanet)
        if mode.planetX == 0: 
            mode.planetX = random.randint(500, 1000)
            mode.planetY = 0

    def createPlanets(mode):
        for planet in mode.planetList:
            if planet == "earth":
                mode.allowEarth = True
            if planet == "mars":
                mode.allowMars = True 
            if planet == "moon":
                mode.allowMoon = True

    def drawEarth(mode, canvas):
        if mode.allowEarth == True:
            canvas.create_image(mode.planetX, mode.planetY, image=ImageTk.PhotoImage(mode.earth))
  
    def drawMars(mode, canvas):
        if mode.allowMars == True: 
            canvas.create_image(mode.planetX, mode.planetY, image=ImageTk.PhotoImage(mode.mars))
    
    def drawMoon(mode, canvas):
        if mode.allowMoon == True:
            canvas.create_image(mode.planetX, mode.planetY, image=ImageTk.PhotoImage(mode.moon))
    
    def bulletHitsPlanet(mode):
        for i in range(len(mode.bullets)):
            if (mode.bullets[i][0]- 50 < mode.planetX < mode.bullets[i][0] + 50 
            and mode.bullets[i][1]- 50  <mode.planetY < mode.bullets[i][1] + 50):
                mode.score += 1 
                mode.planetX = random.randint(500, 1000)
                mode.planetY = 0 

    def createDiamond(mode, canvas):
        canvas.create_image(mode.diamondX, mode.diamondY, 
                            image=ImageTk.PhotoImage(mode.diamond))

    def moveDiamond(mode):
        if mode.diamondX >= 0:
            mode.diamondX -= 40 
        else: 
            mode.diamondX = 1000
            mode.diamondY = random.randint(0, 500) 
    
    def checkDiamond(mode):
        if (mode.characterX - 30 <= mode.diamondX < mode.characterX + 30 and
            mode.characterY - 30 <= mode.diamondY <= mode.characterY + 30):
            mode.score += 1 
            mode.diamondCount += 1
            mode.diamondX = 1000
            mode.diamondY = random.randint(0, 500) 

    def createHearts(mode, canvas):
        for i in range(mode.heartCount):
            canvas.create_image(mode.heartList[i], mode.heartsY, 
                                image=ImageTk.PhotoImage(mode.hearts))

    def calculateHearts(mode):
        if mode.heartCount > 0:  
            if mode.collision == True:
                mode.characterX = 50
                mode.characterY = mode.height/2   
                mode.heartList.pop()
                mode.heartCount -= 1
                mode.collision = False 
            for wall in mode.wallList:
                if ((wall[0] < mode.characterX <= wall[2] 
                        and wall[1] < mode.characterY < wall[3])
                    or
                    (mode.planetX - 40 < mode.characterX < mode.planetX + 40
                        and mode.planetY - 40 < mode.characterY < mode.planetY + 40)):
                    #it reads it but does not work..? jk now it works! :D
                    mode.collision = True 

            if mode.wallList2 != []:
                for wall in mode.wallList2: 
                    if (wall[0] < mode.characterX < wall[2] 
                            and wall[1] < mode.characterY < wall[3]):
                        mode.collision = True

        elif mode.heartCount == 0:
            mode.gameOver = True  
        #check the lowerbound with Y2
        #check the upperbound with Y1     

    def createBackground(mode, canvas):
        canvas.create_image(500, 260, 
                            image=ImageTk.PhotoImage(mode.okayScreen))

    def createCharacter(mode, canvas):
        if mode.alive:
            canvas.create_image(mode.characterX-10,mode.characterY-10,
                            image=ImageTk.PhotoImage(mode.mewScaled))

    def moveCharacter(mode, dx, dy):
        if 0 <= mode.characterX <= 1000 and 0 <= mode.characterY <= 500:
            mode.characterX += dx 
            mode.characterY += dy 

    def fallingCharacter(mode):
        if mode.characterY <= 485:
            mode.characterY += 8

    def randomWall(mode):
        randomNumber = random.choice([0, 1, 2, 3, 4, 4, 4, 5])
        if randomNumber == 0:
            return "0"
        if randomNumber == 1:
            return "1"
        if randomNumber == 2:
            return "2"
        if randomNumber == 3:
            return "3"
        if randomNumber == 4:
            return "4"
        if randomNumber == 5:
            return "5"

    def drawWall(mode, canvas):
        for wall in mode.wallList:
            canvas.create_rectangle(
                wall[0], wall[1], wall[2], wall[3], fill = "black")
        for wall in mode.wallList2:
            canvas.create_rectangle(
                wall[0], wall[1], wall[2], wall[3], fill = "black")
        
    def createWall(mode):
        if (len(mode.wallList) == 1 and mode.wallList[0][2] < 500) or (len(mode.wallList) == 0):
            obsX0 = mode.width 
            obsX1 = 1100
            if mode.randomWall() == "0":
                obsY0 = mode.height - random.randint(100, 400)
                obsY1 = mode.height
            elif mode.randomWall() == "1":
                obsY0 = random.randint(200, 400)
                obsY1 = random.randint(300, 400)
            elif mode.randomWall() == "2":
                obsY0 = mode.height - random.randint(100, 400)
                obsY1 = mode.height
                obsX1 = random.randint(1200,1400)
            elif mode.randomWall() == "3":
                obsY0 = 0
                obsY1 = random.randint(100, 400)
                obsX1 = random.randint(1200,1400)
            elif mode.randomWall() == "4":
                obsY0 = 0 
                obsY1 = random.randint(100, 200)
                obsY2 = mode.height - random.randint(100, 300)
                obsY3 = mode.height 
                while obsY2 - obsY1 < mode.mewScaled.size[1]: 
                    obsY1 = random.randint(100, 200)
                    obsY2 = mode.height - random.randint(100, 300)
                mode.wallList2.append([obsX0, obsY2, obsX1, obsY3, False])
            else:
                obsY0 = 0
                obsY1 = random.randint(100, 400)
            mode.wallList.append([obsX0, obsY0, obsX1, obsY1, False])
            
        
    def moveWall(mode):
        for wall in mode.wallList:
            if wall[2] >= 0:
                wall[0] -= 35 
                wall[2] -= 35
                if mode.score >= 10:
                    wall[0] -= 45
                    wall[2] -= 45
                    if mode.score >= 20:
                        wall[0] -= 55
                        wall[2] -= 55
        for wall in mode.wallList2:
            if wall[2] >= 0:
                wall[0] -= 35
                wall[2] -= 35
                if mode.score > 10:
                    wall[0] -= 45
                    wall[2] -= 45
                    if mode.score >= 20:
                        wall[0] -= 55
                        wall[2] -= 55

    def removeWall(mode):
        i = 0
        while i < len(mode.wallList):
            if mode.wallList[i][2] <= 0:
                mode.wallList.pop(i)
                if mode.wallList2 != []:
                    if mode.wallList2[i][2] <= 0:
                        mode.wallList2.pop(i)
            else: 
                i += 1 

    def movedPastObstacle(mode):
        for wall in mode.wallList:
            if mode.characterX > wall[2] and wall[4] == False:
                mode.score += 1
                wall[4] = True

    def collisionWall(mode):
        for wall in mode.wallList:
            if wall[0] < mode.characterX < wall[2] and wall[0] < mode.characterY < wall[3]:
                mode.collision = True 

    def goGameOver(mode):
        if mode.gameOver == True:
            mode.appStarted()
            mode.app.setActiveMode(mode.app.gameOverScreen)   

    def drawScore(mode, canvas):
        canvas.create_text(930, 18, text = f'Score: {mode.score}/30', 
        fill = 'white', font = f'arial 20 roman bold')
        canvas.create_text(750, 18, text = f'Diamond Collected: {mode.diamondCount}', 
        fill = 'white', font = f'arial 20 roman bold')
    
    def bossEntrance(mode):
        if mode.score == 30: 
            mode.app.setActiveMode(mode.app.mediumBossTransition)

    def timerFired(mode):
        if (not mode.paused):
            mode.fallingPlanets()
            mode.calculateHearts()
            #mode.collisionWall()
            mode.movedPastObstacle()
            mode.checkDiamond()
            mode.createWall()
            mode.moveWall() 
            mode.removeWall()
            mode.fallingCharacter()
            mode.moveDiamond() 
            mode.randomPlanets()
            mode.moveBullet() 
            mode.removeBullet()
            mode.bossEntrance()
            mode.goGameOver()
            mode.generatePlanets()
            mode.createPlanets()
            mode.bulletHitsPlanet()
        if mode.gameOver == False:
            mode.movedPastObstacle()

    def redrawAll(mode, canvas): 
        mode.createBackground(canvas)
        mode.createHearts(canvas)
        mode.createDiamond(canvas)
        mode.drawWall(canvas)
        mode.createCharacter(canvas)
        mode.drawScore(canvas)
        mode.drawBullet(canvas)
        mode.drawEarth(canvas)
        mode.drawMoon(canvas)
        mode.drawMars(canvas)

class GameModeHard(Mode):
    def appStarted(mode):
        mode.timerDelay = 50
        mode.obstacleOn = False
        mode.characterX = 50
        mode.characterY = mode.height - 50
        mode.alive = True
        mode.falling = False 
        mode.score = 0 
        mode.gameOver = False 
        mode.margin = 5 
        mode.paused = False 
        mode.mew = mode.loadImage('mew.png')
        #image from https://www.pngitem.com/middle/ihmxRTw_hat-png-images-transparent-pixel-art-pokemon-mew/
        mode.mewScaled = mode.scaleImage(mode.mew, 1/10)
        mode.background0 = mode.loadImage('hell.png')
        #image from https://www.artstation.com/artwork/qaZwP
        mode.background = mode.scaleImage(mode.background0, 1.6)
        mode.hearts0 = mode.loadImage('hearts.png')
        #image from https://www.pngkit.com/bigpic/u2q8a9t4i1q8y3r5/
        mode.hearts = mode.scaleImage(mode.hearts0, 1/25)
        mode.heartsX = 30 
        mode.heartsY = 30 
        mode.diamond0 = mode.loadImage('diamond.png')
        #https://toppng.com/minecraft-diamond-wallpaper-pin-pin-diamond-minecraft-pixel-art-minecraft-diamant-PNG-free-PNG-Images_251843?search-result=minecraft-number-8
        mode.diamond = mode.scaleImage(mode.diamond0, 1/8)
        mode.diamondX = mode.width
        mode.diamondY = random.randint(0, 300) 
        #mode.diamonds = [] pop the diamond (x,y)
        powerUps = [mode.diamond]
        mode.earth0 = mode.loadImage('earth.png')
        #image from http://pixelartmaker.com/art/4a656cb5e171a69
        mode.earth = mode.scaleImage(mode.earth0, 0.3)
        mode.mars0 = mode.loadImage('mars.png')
        #image from http://pixelartmaker.com/art/ede5adce918dcf4
        mode.mars = mode.scaleImage(mode.mars0, 0.3)
        mode.moon0 = mode.loadImage('moon.png')
        #image from https://www.reddit.com/r/PixelArt/comments/99ipqb/cc_moon_pixel_art_i_would_like_some_feed_back/
        mode.moon = mode.scaleImage(mode.moon0, 0.1)
        mode.planets = ["earth", "mars", "moon"]
        mode.heartCount = 3
        mode.bullet0 = mode.loadImage('bullet.png')
        #image from http://pixelartmaker.com/gallery?after=638985
        mode.bullet = mode.scaleImage(mode.bullet0, 0.1)
        mode.bullets = [] 
        mode.wallList = [] 
        mode.heartList = [mode.heartsX, mode.heartsX+45, mode.heartsX+90] 
        mode.collision = False
        mode.diamondCount = 0 
        mode.planetX = random.randint(500, 1000)
        mode.planetY = -100
        mode.planetList = []
        mode.fallingPlanet = "planet" 
        mode.randomPlanetNumber = 0
        mode.allowEarth = False
        mode.allowMars = False 
        mode.allowMoon = False
        mode.wallList2 = []
        mode.okayScreen0 = mode.loadImage('mediumscreen.png')
        #image from https://weheartit.com/entry/335148442
        mode.okayScreen = mode.scaleImage(mode.okayScreen0, 1.3)

    def keyPressed(mode, event): 
        if (event.key == 'Up'):      
            if mode.score < 10:
                mode.moveCharacter(0, -40)
            else: 
                mode.moveCharacter(0, -50)
        elif (event.key == 'Down'):  
            if mode.score < 10: 
                mode.moveCharacter(0, 30) 
            else: 
                mode.moveCharacter(0, 50) 
        elif (event.key == 'Left'):  
            mode.moveCharacter(-20, 0) 
        elif (event.key == 'Right'): 
            mode.moveCharacter(20, 0)
        elif (event.key == 'r'):
            mode.appStarted()
        elif (event.key == 'Space'):
            mode.fireBullet() 
        elif (event.key == 'p'):
            mode.paused = not mode.paused
        else:
            mode.Falling = True 
            move.fallingCharacter()

    def fireBullet(mode):
        originBulletX = mode.characterX + 20 
        startBulletX = mode.characterX + 20 
        startBulletY = mode.characterY    
        mode.bullets.append([startBulletX, startBulletY, originBulletX])

    def drawBullet(mode, canvas):
        for bullet in mode.bullets:
            canvas.create_image(bullet[0], bullet[1], image=ImageTk.PhotoImage(mode.bullet))

    def moveBullet(mode):
        for i in range(len(mode.bullets)):
            bulletTrajX = mode.bullets[i][0] + 50
            bulletTrajY = mode.bullets[i][1] 
            mode.bullets[i] = [bulletTrajX, bulletTrajY, mode.bullets[i][2]]

    def removeBullet(mode):
        i = 0 
        while i < len(mode.bullets):
            if mode.bullets[i][0] - mode.bullets[i][2] > 500:
                mode.bullets.pop(i)
            else: 
                i += 1 

    def randomPlanets(mode):
        randomNumber = random.choice([0, 1, 2])
        mode.randomPlanetNumber = randomNumber

    def fallingPlanets(mode):
        if mode.planetX > 0: 
            mode.planetX -= 20 
            mode.planetY += 20

    def generatePlanets(mode):
        if (len(mode.planetList) == 1 and mode.planetX < 300) or (len(mode.planetList) == 0):
            if mode.randomPlanetNumber == 0:
                mode.fallingPlanet = mode.planets[0]
            elif mode.randomPlanetNumber == 1:
                mode.fallingPlanet = mode.planets[1]
            elif mode.randomPlanetNumber == 2: 
                mode.fallingPlanet = mode.planets[2]
            mode.planetList.append(mode.fallingPlanet)
        if mode.planetX == 0: 
            mode.planetX = random.randint(500, 1000)
            mode.planetY = 0

    def createPlanets(mode):
        for planet in mode.planetList:
            if planet == "earth":
                mode.allowEarth = True
            if planet == "mars":
                mode.allowMars = True 
            if planet == "moon":
                mode.allowMoon = True

    def drawEarth(mode, canvas):
        if mode.allowEarth == True:
            canvas.create_image(mode.planetX, mode.planetY, image=ImageTk.PhotoImage(mode.earth))
  
    def drawMars(mode, canvas):
        if mode.allowMars == True: 
            canvas.create_image(mode.planetX, mode.planetY, image=ImageTk.PhotoImage(mode.mars))
    
    def drawMoon(mode, canvas):
        if mode.allowMoon == True:
            canvas.create_image(mode.planetX, mode.planetY, image=ImageTk.PhotoImage(mode.moon))
    
    def bulletHitsPlanet(mode):
        for i in range(len(mode.bullets)):
            if (mode.bullets[i][0]- 50 < mode.planetX < mode.bullets[i][0] + 50 
            and mode.bullets[i][1]- 50  <mode.planetY < mode.bullets[i][1] + 50):
                mode.score += 1 
                mode.planetX = random.randint(500, 1000)
                mode.planetY = 0 

    def createDiamond(mode, canvas):
        canvas.create_image(mode.diamondX, mode.diamondY, 
                            image=ImageTk.PhotoImage(mode.diamond))

    def moveDiamond(mode):
        if mode.diamondX >= 0:
            mode.diamondX -= 40 
        else: 
            mode.diamondX = 1000
            mode.diamondY = random.randint(0, 500) 
    
    def checkDiamond(mode):
        if (mode.characterX - 30 <= mode.diamondX < mode.characterX + 30 and
            mode.characterY - 30 <= mode.diamondY <= mode.characterY + 30):
            mode.score += 1 
            mode.diamondCount += 1
            mode.diamondX = 1000
            mode.diamondY = random.randint(0, 500) 

    def createHearts(mode, canvas):
        for i in range(mode.heartCount):
            canvas.create_image(mode.heartList[i], mode.heartsY, 
                                image=ImageTk.PhotoImage(mode.hearts))

    def calculateHearts(mode):
        if mode.heartCount > 0:  
            if mode.collision == True:
                mode.characterX = 50
                mode.characterY = mode.height/2   
                mode.heartList.pop()
                mode.heartCount -= 1
                mode.collision = False 
            for wall in mode.wallList:
                if ((wall[0] < mode.characterX <= wall[2] 
                        and wall[1] < mode.characterY < wall[3])
                    or
                    (mode.planetX - 40 < mode.characterX < mode.planetX + 40
                        and mode.planetY - 40 < mode.characterY < mode.planetY + 40)):
                    #it reads it but does not work..? jk now it works! :D
                    mode.collision = True 

            if mode.wallList2 != []:
                for wall in mode.wallList2: 
                    if (wall[0] < mode.characterX < wall[2] 
                            and wall[1] < mode.characterY < wall[3]):
                        mode.collision = True

        elif mode.heartCount == 0:
            mode.gameOver = True  
        #check the lowerbound with Y2
        #check the upperbound with Y1     

    def createBackground(mode, canvas):
        canvas.create_image(500, 260, 
                            image=ImageTk.PhotoImage(mode.background))

    def createCharacter(mode, canvas):
        if mode.alive:
            canvas.create_image(mode.characterX-10,mode.characterY-10,
                            image=ImageTk.PhotoImage(mode.mewScaled))

    def moveCharacter(mode, dx, dy):
        if 0 <= mode.characterX <= 1000 and 0 <= mode.characterY <= 500:
            mode.characterX += dx 
            mode.characterY += dy 

    def fallingCharacter(mode):
        if mode.characterY <= 485:
            mode.characterY += 8

    def randomWall(mode):
        randomNumber = random.choice([0, 1, 2, 3, 4, 4, 4, 5])
        if randomNumber == 0:
            return "0"
        if randomNumber == 1:
            return "1"
        if randomNumber == 2:
            return "2"
        if randomNumber == 3:
            return "3"
        if randomNumber == 4:
            return "4"
        if randomNumber == 5:
            return "5"

    def drawWall(mode, canvas):
        for wall in mode.wallList:
            canvas.create_rectangle(
                wall[0], wall[1], wall[2], wall[3], fill = "black")
        for wall in mode.wallList2:
            canvas.create_rectangle(
                wall[0], wall[1], wall[2], wall[3], fill = "black")
        
    def createWall(mode):
        if (len(mode.wallList) == 1 and mode.wallList[0][2] < 500) or (len(mode.wallList) == 0):
            obsX0 = mode.width 
            obsX1 = 1100
            if mode.randomWall() == "0":
                obsY0 = mode.height - random.randint(100, 400)
                obsY1 = mode.height
            elif mode.randomWall() == "1":
                obsY0 = random.randint(200, 400)
                obsY1 = random.randint(300, 400)
            elif mode.randomWall() == "2":
                obsY0 = mode.height - random.randint(100, 400)
                obsY1 = mode.height
                obsX1 = random.randint(1200,1400)
            elif mode.randomWall() == "3":
                obsY0 = 0
                obsY1 = random.randint(100, 400)
                obsX1 = random.randint(1200,1400)
            elif mode.randomWall() == "4":
                obsY0 = 0 
                obsY1 = random.randint(100, 200)
                obsY2 = mode.height - random.randint(100, 300)
                obsY3 = mode.height 
                while obsY2 - obsY1 < mode.mewScaled.size[1]: 
                    obsY1 = random.randint(100, 200)
                    obsY2 = mode.height - random.randint(100, 300)
                mode.wallList2.append([obsX0, obsY2, obsX1, obsY3, False])
            else:
                obsY0 = 0
                obsY1 = random.randint(100, 400)
            mode.wallList.append([obsX0, obsY0, obsX1, obsY1, False])
            
        
    def moveWall(mode):
        for wall in mode.wallList:
            if wall[2] >= 0:
                wall[0] -= 45 
                wall[2] -= 45
                if mode.score >= 10:
                    wall[0] -= 55
                    wall[2] -= 55
                    if mode.score >= 20:
                        wall[0] -= 65
                        wall[2] -= 65
        for wall in mode.wallList2:
            if wall[2] >= 0:
                wall[0] -= 45
                wall[2] -= 45
                if mode.score > 10:
                    wall[0] -= 55
                    wall[2] -= 55
                    if mode.score >= 20:
                        wall[0] -= 65
                        wall[2] -= 65

    def removeWall(mode):
        i = 0
        while i < len(mode.wallList):
            if mode.wallList[i][2] <= 0:
                mode.wallList.pop(i)
                if mode.wallList2 != []:
                    if mode.wallList2[i][2] <= 0:
                        mode.wallList2.pop(i)
            else: 
                i += 1 

    def movedPastObstacle(mode):
        for wall in mode.wallList:
            if mode.characterX > wall[2] and wall[4] == False:
                mode.score += 1
                wall[4] = True

    def collisionWall(mode):
        for wall in mode.wallList:
            if wall[0] < mode.characterX < wall[2] and wall[0] < mode.characterY < wall[3]:
                mode.collision = True 

    def goGameOver(mode):
        if mode.gameOver == True:
            mode.appStarted()
            mode.app.setActiveMode(mode.app.gameOverScreen)   

    def drawScore(mode, canvas):
        canvas.create_text(930, 18, text = f'Score: {mode.score}/30', 
        fill = 'white', font = f'arial 20 roman bold')
        canvas.create_text(750, 18, text = f'Diamond Collected: {mode.diamondCount}', 
        fill = 'white', font = f'arial 20 roman bold')
    
    def bossEntrance(mode):
        if mode.score == 30: 
            mode.app.setActiveMode(mode.app.mediumBossTransition)

    def timerFired(mode):
        if (not mode.paused):
            mode.fallingPlanets()
            mode.calculateHearts()
            #mode.collisionWall()
            mode.movedPastObstacle()
            mode.checkDiamond()
            mode.createWall()
            mode.moveWall() 
            mode.removeWall()
            mode.fallingCharacter()
            mode.moveDiamond() 
            mode.randomPlanets()
            mode.moveBullet() 
            mode.removeBullet()
            mode.bossEntrance()
            mode.goGameOver()
            mode.generatePlanets()
            mode.createPlanets()
            mode.bulletHitsPlanet()
        if mode.gameOver == False:
            mode.movedPastObstacle()

    def redrawAll(mode, canvas): 
        mode.createBackground(canvas)
        mode.createHearts(canvas)
        mode.createDiamond(canvas)
        mode.drawWall(canvas)
        mode.createCharacter(canvas)
        mode.drawScore(canvas)
        mode.drawBullet(canvas)
        mode.drawEarth(canvas)
        mode.drawMoon(canvas)
        mode.drawMars(canvas)

class EasyBossTransition(Mode):
    def appStarted(mode):
        mode.timerDelay = 50
        mode.background0 = mode.loadImage('background.jpg')
        mode.background = mode.scaleImage(mode.background0, 1.6)
        mode.mew = mode.loadImage('mew.png')
        mode.mewScaled = mode.scaleImage(mode.mew, 1/10)
        mode.characterX = 50
        mode.characterY = mode.height - 50
        mode.paused = False 
        mode.bullet0 = mode.loadImage('bullet.png')
        mode.bullet = mode.scaleImage(mode.bullet0, 0.1)
        mode.bullets = [] 
        mode.boss0 = mode.loadImage("easyboss.png")
        #image from https://www.pikpng.com/pngvi/obxTix_va-pixel-art-spray-overwatch-d-va-pixel-spray-clipart/
        mode.earth0 = mode.loadImage('earth.png')
        mode.earth = mode.scaleImage(mode.earth0, 0.3)
        mode.mars0 = mode.loadImage('mars.png')
        mode.mars = mode.scaleImage(mode.mars0, 0.3)
        mode.moon0 = mode.loadImage('moon.png')
        mode.moon = mode.scaleImage(mode.moon0, 0.1)
        mode.planets = ["earth", "mars", "moon"]
        mode.allowEarth = False
        mode.allowMars = False
        mode.allowMoon = False
        mode.planetList = []
        mode.randomPlanetNumber = 0
        mode.planetX = 850 
        mode.planetY = random.randint(100, 400)
        mode.health = 2000
    
    def keyPressed(mode, event):
        if (event.key == 'Up'):      
            mode.moveCharacter(0, -40)
        elif (event.key == 'Down'):   
            mode.moveCharacter(0, 20) 
        elif (event.key == 'Left'):  
            mode.moveCharacter(-20, 0) 
        elif (event.key == 'Right'): 
            mode.moveCharacter(20, 0)
        elif (event.key == 'r'):
            mode.appStarted()
        elif (event.key == 'Space'):
            mode.fireBullet() 
        elif (event.key == 'p'):
            mode.paused = not mode.paused
        else:
            mode.Falling = True 
            move.fallingCharacter()

    def createCharacter(mode, canvas):
        canvas.create_image(mode.characterX-10,mode.characterY-10,
                            image=ImageTk.PhotoImage(mode.mewScaled))

    def moveCharacter(mode, dx, dy):
        if 0 <= mode.characterX <= 1000 and 0 <= mode.characterY <= 500:
            mode.characterX += dx 
            mode.characterY += dy 

    def fallingCharacter(mode):
        if mode.characterY <= 485:
            mode.characterY += 8

    def fireBullet(mode):
        originBulletX = mode.characterX + 20 
        startBulletX = mode.characterX + 20 
        startBulletY = mode.characterY    
        mode.bullets.append([startBulletX, startBulletY, originBulletX])

    def drawBullet(mode, canvas):
        for bullet in mode.bullets:
            canvas.create_image(bullet[0], bullet[1], image=ImageTk.PhotoImage(mode.bullet))

    def moveBullet(mode):
        for i in range(len(mode.bullets)):
            bulletTrajX = mode.bullets[i][0] + 50
            bulletTrajY = mode.bullets[i][1] 
            mode.bullets[i] = [bulletTrajX, bulletTrajY, mode.bullets[i][2]]

    def removeBullet(mode):
        i = 0 
        while i < len(mode.bullets):
            if mode.bullets[i][0] - mode.bullets[i][2] > 500:
                mode.bullets.pop(i)
            else: 
                i += 1 
    
    def randomPlanets(mode):
        randomNumber = random.choice([0, 1, 2])
        mode.randomPlanetNumber = randomNumber

    def thrownPlanets(mode):
        if mode.planetX > 0: 
            mode.planetX -= 50
            mode.planetY += 0

    def generatePlanets(mode):
        if (len(mode.planetList) == 1 and mode.planetX < 300) or (len(mode.planetList) == 0):
            if mode.randomPlanetNumber == 0:
                mode.fallingPlanet = mode.planets[0]
            elif mode.randomPlanetNumber == 1:
                mode.fallingPlanet = mode.planets[1]
            elif mode.randomPlanetNumber == 2: 
                mode.fallingPlanet = mode.planets[2]
            mode.planetList.append(mode.fallingPlanet)
        if mode.planetX == 0: 
            mode.planetX = 850 
            mode.planetY = random.randint(100, 400)

    def createPlanets(mode):
        for planet in mode.planetList:
            if planet == "earth":
                mode.allowEarth = True
            if planet == "mars":
                mode.allowMars = True 
            if planet == "moon":
                mode.allowMoon = True

    def drawEarth(mode, canvas):
        if mode.allowEarth == True:
            canvas.create_image(mode.planetX, mode.planetY, image=ImageTk.PhotoImage(mode.earth))
  
    def drawMars(mode, canvas):
        if mode.allowMars == True: 
            canvas.create_image(mode.planetX, mode.planetY, image=ImageTk.PhotoImage(mode.mars))
    
    def drawMoon(mode, canvas):
        if mode.allowMoon == True:
            canvas.create_image(mode.planetX, mode.planetY, image=ImageTk.PhotoImage(mode.moon))
    
    def bulletHitsPlanet(mode):
        for i in range(len(mode.bullets)):
            if (mode.bullets[i][0]- 50 < mode.planetX < mode.bullets[i][0] + 50 
            and mode.bullets[i][1]- 50  <mode.planetY < mode.bullets[i][1] + 50):
                mode.planetX = random.randint(500, 1000)
                mode.planetY = random.randint(100, 400)
                mode.health -= 100
            elif mode.planetX == 0: 
                mode.planetX = random.randint(500, 1000)
                mode.planetY = random.randint(100, 400)

    def loseBoss(mode):
        if (mode.planetX - 40 < mode.characterX < mode.planetX + 40 
                        and mode.planetY- 40 < mode.characterY + 40):
            mode.app.setActiveMode(mode.app.gameOverScreen)  
    
    def goVictory(mode):
        if mode.health == 0:
            mode.app.setActiveMode(mode.app.victoryScreen)  

    def timerFired(mode):
        mode.fallingCharacter()
        mode.moveBullet() 
        mode.removeBullet()
        mode.removeBullet()
        mode.generatePlanets()
        mode.createPlanets()
        mode.thrownPlanets()
        mode.bulletHitsPlanet()
        mode.loseBoss()
        mode.goVictory()

    def redrawAll(mode, canvas):
        canvas.create_image(500, 260, 
                            image=ImageTk.PhotoImage(mode.background))
        mode.createCharacter(canvas)
        mode.drawBullet(canvas)
        canvas.create_image(800, 260, 
                            image=ImageTk.PhotoImage(mode.boss0))
        mode.drawEarth(canvas)
        mode.drawMoon(canvas) 
        mode.drawMars(canvas)
        canvas.create_text(800, 80, text = f'Boss Health {mode.health}/2000', 
        fill = 'white', font = f'arial 20 roman bold')

class MediumBossTransition(Mode):
    def appStarted(mode):
        mode.timerDelay = 50
        mode.okayScreen0 = mode.loadImage('mediumscreen.png')
        mode.okayScreen = mode.scaleImage(mode.okayScreen0, 1.3)
        mode.mew = mode.loadImage('mew.png')
        mode.mewScaled = mode.scaleImage(mode.mew, 1/10)
        mode.characterX = 50
        mode.characterY = mode.height - 50
        mode.paused = False 
        mode.bullet0 = mode.loadImage('bullet.png')
        mode.bullet = mode.scaleImage(mode.bullet0, 0.1)
        mode.bullets = [] 
        mode.boss0 = mode.loadImage("easyboss.png")
        #image from https://www.pikpng.com/pngvi/obxTix_va-pixel-art-spray-overwatch-d-va-pixel-spray-clipart/
        mode.earth0 = mode.loadImage('earth.png')
        mode.earth = mode.scaleImage(mode.earth0, 0.3)
        mode.mars0 = mode.loadImage('mars.png')
        mode.mars = mode.scaleImage(mode.mars0, 0.3)
        mode.moon0 = mode.loadImage('moon.png')
        mode.moon = mode.scaleImage(mode.moon0, 0.1)
        mode.planets = ["earth", "mars", "moon"]
        mode.allowEarth = False
        mode.allowMars = False
        mode.allowMoon = False
        mode.planetList = []
        mode.randomPlanetNumber = 0
        mode.planetX = 850 
        mode.planetY = random.randint(100, 400)
        mode.health = 3000
    
    def keyPressed(mode, event):
        if (event.key == 'Up'):      
            mode.moveCharacter(0, -40)
        elif (event.key == 'Down'):   
            mode.moveCharacter(0, 20) 
        elif (event.key == 'Left'):  
            mode.moveCharacter(-20, 0) 
        elif (event.key == 'Right'): 
            mode.moveCharacter(20, 0)
        elif (event.key == 'r'):
            mode.appStarted()
        elif (event.key == 'Space'):
            mode.fireBullet() 
        elif (event.key == 'p'):
            mode.paused = not mode.paused
        else:
            mode.Falling = True 
            move.fallingCharacter()

    def createCharacter(mode, canvas):
        canvas.create_image(mode.characterX-10,mode.characterY-10,
                            image=ImageTk.PhotoImage(mode.mewScaled))

    def moveCharacter(mode, dx, dy):
        if 0 <= mode.characterX <= 1000 and 0 <= mode.characterY <= 500:
            mode.characterX += dx 
            mode.characterY += dy 

    def fallingCharacter(mode):
        if mode.characterY <= 485:
            mode.characterY += 8

    def fireBullet(mode):
        originBulletX = mode.characterX + 20 
        startBulletX = mode.characterX + 20 
        startBulletY = mode.characterY    
        mode.bullets.append([startBulletX, startBulletY, originBulletX])

    def drawBullet(mode, canvas):
        for bullet in mode.bullets:
            canvas.create_image(bullet[0], bullet[1], image=ImageTk.PhotoImage(mode.bullet))

    def moveBullet(mode):
        for i in range(len(mode.bullets)):
            bulletTrajX = mode.bullets[i][0] + 50
            bulletTrajY = mode.bullets[i][1] 
            mode.bullets[i] = [bulletTrajX, bulletTrajY, mode.bullets[i][2]]

    def removeBullet(mode):
        i = 0 
        while i < len(mode.bullets):
            if mode.bullets[i][0] - mode.bullets[i][2] > 500:
                mode.bullets.pop(i)
            else: 
                i += 1 
    
    def randomPlanets(mode):
        randomNumber = random.choice([0, 1, 2])
        mode.randomPlanetNumber = randomNumber

    def thrownPlanets(mode):
        if mode.planetX > 0: 
            mode.planetX -= 60
            mode.planetY += 0

    def generatePlanets(mode):
        if (len(mode.planetList) == 1 and mode.planetX < 300) or (len(mode.planetList) == 0):
            if mode.randomPlanetNumber == 0:
                mode.fallingPlanet = mode.planets[0]
            elif mode.randomPlanetNumber == 1:
                mode.fallingPlanet = mode.planets[1]
            elif mode.randomPlanetNumber == 2: 
                mode.fallingPlanet = mode.planets[2]
            mode.planetList.append(mode.fallingPlanet)
        if mode.planetX == 0: 
            mode.planetX = 850 
            mode.planetY = random.randint(100, 400)

    def createPlanets(mode):
        for planet in mode.planetList:
            if planet == "earth":
                mode.allowEarth = True
            if planet == "mars":
                mode.allowMars = True 
            if planet == "moon":
                mode.allowMoon = True

    def drawEarth(mode, canvas):
        if mode.allowEarth == True:
            canvas.create_image(mode.planetX, mode.planetY, image=ImageTk.PhotoImage(mode.earth))
  
    def drawMars(mode, canvas):
        if mode.allowMars == True: 
            canvas.create_image(mode.planetX, mode.planetY, image=ImageTk.PhotoImage(mode.mars))
    
    def drawMoon(mode, canvas):
        if mode.allowMoon == True:
            canvas.create_image(mode.planetX, mode.planetY, image=ImageTk.PhotoImage(mode.moon))
    
    def bulletHitsPlanet(mode):
        for i in range(len(mode.bullets)):
            if (mode.bullets[i][0]- 50 < mode.planetX < mode.bullets[i][0] + 50 
            and mode.bullets[i][1]- 50  <mode.planetY < mode.bullets[i][1] + 50):
                mode.planetX = random.randint(500, 1000)
                mode.planetY = random.randint(100, 400)
                mode.health -= 100
            elif mode.planetX == 0: 
                mode.planetX = random.randint(500, 1000)
                mode.planetY = random.randint(100, 400)

    def loseBoss(mode):
        if (mode.planetX - 40 < mode.characterX < mode.planetX + 40 
                        and mode.planetY- 40 < mode.characterY + 40):
            mode.app.setActiveMode(mode.app.gameOverScreen)  
    
    def goVictory(mode):
        if mode.health == 0:
            mode.app.setActiveMode(mode.app.victoryScreen)  

    def timerFired(mode):
        mode.fallingCharacter()
        mode.moveBullet() 
        mode.removeBullet()
        mode.removeBullet()
        mode.generatePlanets()
        mode.createPlanets()
        mode.thrownPlanets()
        mode.bulletHitsPlanet()
        mode.loseBoss()
        mode.goVictory()

    def redrawAll(mode, canvas):
        canvas.create_image(500, 260, 
                            image=ImageTk.PhotoImage(mode.okayScreen))
        mode.createCharacter(canvas)
        mode.drawBullet(canvas)
        canvas.create_image(800, 260, 
                            image=ImageTk.PhotoImage(mode.boss0))
        mode.drawEarth(canvas)
        mode.drawMoon(canvas) 
        mode.drawMars(canvas)
        canvas.create_text(800, 80, text = f'Boss Health {mode.health}/2000', 
        fill = 'white', font = f'arial 20 roman bold')

class HardBossTransition(Mode):
    def appStarted(mode):
        mode.timerDelay = 50
        mode.okayScreen0 = mode.loadImage('hell.png')
        mode.okayScreen = mode.scaleImage(mode.hell, 1.6)
        mode.mew = mode.loadImage('mew.png')
        mode.mewScaled = mode.scaleImage(mode.mew, 1/10)
        mode.characterX = 50
        mode.characterY = mode.height - 50
        mode.paused = False 
        mode.bullet0 = mode.loadImage('bullet.png')
        mode.bullet = mode.scaleImage(mode.bullet0, 0.1)
        mode.bullets = [] 
        mode.boss0 = mode.loadImage("easyboss.png")
        #image from https://www.pikpng.com/pngvi/obxTix_va-pixel-art-spray-overwatch-d-va-pixel-spray-clipart/
        mode.earth0 = mode.loadImage('earth.png')
        mode.earth = mode.scaleImage(mode.earth0, 0.3)
        mode.mars0 = mode.loadImage('mars.png')
        mode.mars = mode.scaleImage(mode.mars0, 0.3)
        mode.moon0 = mode.loadImage('moon.png')
        mode.moon = mode.scaleImage(mode.moon0, 0.1)
        mode.planets = ["earth", "mars", "moon"]
        mode.allowEarth = False
        mode.allowMars = False
        mode.allowMoon = False
        mode.planetList = []
        mode.randomPlanetNumber = 0
        mode.planetX = 850 
        mode.planetY = random.randint(100, 400)
        mode.health = 4000
    
    def keyPressed(mode, event):
        if (event.key == 'Up'):      
            mode.moveCharacter(0, -40)
        elif (event.key == 'Down'):   
            mode.moveCharacter(0, 20) 
        elif (event.key == 'Left'):  
            mode.moveCharacter(-20, 0) 
        elif (event.key == 'Right'): 
            mode.moveCharacter(20, 0)
        elif (event.key == 'r'):
            mode.appStarted()
        elif (event.key == 'Space'):
            mode.fireBullet() 
        elif (event.key == 'p'):
            mode.paused = not mode.paused
        else:
            mode.Falling = True 
            move.fallingCharacter()

    def createCharacter(mode, canvas):
        canvas.create_image(mode.characterX-10,mode.characterY-10,
                            image=ImageTk.PhotoImage(mode.mewScaled))

    def moveCharacter(mode, dx, dy):
        if 0 <= mode.characterX <= 1000 and 0 <= mode.characterY <= 500:
            mode.characterX += dx 
            mode.characterY += dy 

    def fallingCharacter(mode):
        if mode.characterY <= 485:
            mode.characterY += 8

    def fireBullet(mode):
        originBulletX = mode.characterX + 20 
        startBulletX = mode.characterX + 20 
        startBulletY = mode.characterY    
        mode.bullets.append([startBulletX, startBulletY, originBulletX])

    def drawBullet(mode, canvas):
        for bullet in mode.bullets:
            canvas.create_image(bullet[0], bullet[1], image=ImageTk.PhotoImage(mode.bullet))

    def moveBullet(mode):
        for i in range(len(mode.bullets)):
            bulletTrajX = mode.bullets[i][0] + 50
            bulletTrajY = mode.bullets[i][1] 
            mode.bullets[i] = [bulletTrajX, bulletTrajY, mode.bullets[i][2]]

    def removeBullet(mode):
        i = 0 
        while i < len(mode.bullets):
            if mode.bullets[i][0] - mode.bullets[i][2] > 500:
                mode.bullets.pop(i)
            else: 
                i += 1 
    
    def randomPlanets(mode):
        randomNumber = random.choice([0, 1, 2])
        mode.randomPlanetNumber = randomNumber

    def thrownPlanets(mode):
        if mode.planetX > 0: 
            mode.planetX -= 60
            mode.planetY += 0

    def generatePlanets(mode):
        if (len(mode.planetList) == 1 and mode.planetX < 300) or (len(mode.planetList) == 0):
            if mode.randomPlanetNumber == 0:
                mode.fallingPlanet = mode.planets[0]
            elif mode.randomPlanetNumber == 1:
                mode.fallingPlanet = mode.planets[1]
            elif mode.randomPlanetNumber == 2: 
                mode.fallingPlanet = mode.planets[2]
            mode.planetList.append(mode.fallingPlanet)
        if mode.planetX == 0: 
            mode.planetX = 850 
            mode.planetY = random.randint(100, 400)

    def createPlanets(mode):
        for planet in mode.planetList:
            if planet == "earth":
                mode.allowEarth = True
            if planet == "mars":
                mode.allowMars = True 
            if planet == "moon":
                mode.allowMoon = True

    def drawEarth(mode, canvas):
        if mode.allowEarth == True:
            canvas.create_image(mode.planetX, mode.planetY, image=ImageTk.PhotoImage(mode.earth))
  
    def drawMars(mode, canvas):
        if mode.allowMars == True: 
            canvas.create_image(mode.planetX, mode.planetY, image=ImageTk.PhotoImage(mode.mars))
    
    def drawMoon(mode, canvas):
        if mode.allowMoon == True:
            canvas.create_image(mode.planetX, mode.planetY, image=ImageTk.PhotoImage(mode.moon))
    
    def bulletHitsPlanet(mode):
        for i in range(len(mode.bullets)):
            if (mode.bullets[i][0]- 50 < mode.planetX < mode.bullets[i][0] + 50 
            and mode.bullets[i][1]- 50  <mode.planetY < mode.bullets[i][1] + 50):
                mode.planetX = random.randint(500, 1000)
                mode.planetY = random.randint(100, 400)
                mode.health -= 100
            elif mode.planetX == 0: 
                mode.planetX = random.randint(500, 1000)
                mode.planetY = random.randint(100, 400)

    def loseBoss(mode):
        if (mode.planetX - 40 < mode.characterX < mode.planetX + 40 
                        and mode.planetY- 40 < mode.characterY + 40):
            mode.app.setActiveMode(mode.app.gameOverScreen)  
    
    def goVictory(mode):
        if mode.health == 0:
            mode.app.setActiveMode(mode.app.victoryScreen)  

    def timerFired(mode):
        mode.fallingCharacter()
        mode.moveBullet() 
        mode.removeBullet()
        mode.removeBullet()
        mode.generatePlanets()
        mode.createPlanets()
        mode.thrownPlanets()
        mode.bulletHitsPlanet()
        mode.loseBoss()
        mode.goVictory()

    def redrawAll(mode, canvas):
        canvas.create_image(500, 260, 
                            image=ImageTk.PhotoImage(mode.okayScreen))
        mode.createCharacter(canvas)
        mode.drawBullet(canvas)
        canvas.create_image(800, 260, 
                            image=ImageTk.PhotoImage(mode.boss0))
        mode.drawEarth(canvas)
        mode.drawMoon(canvas) 
        mode.drawMars(canvas)
        canvas.create_text(800, 80, text = f'Boss Health {mode.health}/2000', 
        fill = 'white', font = f'arial 20 roman bold')

class VictoryScreen(Mode):
    def appStarted(mode):
        mode.galaxy0 = mode.loadImage('galaxy.png')
        mode.galaxy = mode.scaleImage(mode.galaxy0, 1.2)
        mode.youWin0 = mode.loadImage('youwin.png')

    def redrawAll(mode, canvas):
        canvas.create_image(500, -100, image=ImageTk.PhotoImage(mode.galaxy))
        canvas.create_image(500, 260, 
                            image=ImageTk.PhotoImage(mode.youWin0))   

class GameOverScreen(Mode):
    def appStarted(mode):
        mode.galaxy0 = mode.loadImage('galaxy.png')
        mode.galaxy = mode.scaleImage(mode.galaxy0, 1.2)
        mode.gameOverLetters0 = mode.loadImage("gameover.png") 
        mode.gameOverLetters = mode.scaleImage(mode.gameOverLetters0, 0.5)
    
    def mousePressed(mode, event):
        mode.app.setActiveMode(mode.app.splashScreenModeTwo)

    def redrawAll(mode, canvas):
        canvas.create_image(500, -100, image=ImageTk.PhotoImage(mode.galaxy))
        canvas.create_image(500, 200, 
                            image=ImageTk.PhotoImage(mode.gameOverLetters))
        canvas.create_text(500, 350, text = "Click to go back to level selection!", 
        fill = 'white', font = f'arial 30 roman bold')

class MyModalApp(ModalApp):
    def appStarted(app):
        app.splashScreenMode = SplashScreenMode()
        app.splashScreenModeTwo = SplashScreenModeTwo()
        app.easyBossTransition = EasyBossTransition()
        app.gameMode = GameMode()
        app.gameOverScreen = GameOverScreen()
        app.victoryScreen = VictoryScreen()
        app.gameModeMedium = GameModeMedium()
        app.mediumBossTransition = MediumBossTransition() 
        app.gameModeHard = GameModeHard()
        app.setActiveMode(app.splashScreenMode)
        

app = MyModalApp(width=1000, height=500)

